// payments.js — COMMONJS VERSION

const ddb = require("./db.js");
const {
  PutCommand,
  GetCommand,
  ScanCommand,
  DeleteCommand,
  UpdateCommand,
  QueryCommand
} = require("@aws-sdk/lib-dynamodb");

const TABLE = process.env.PAYMENTS_TABLE || "PGPayments";

// ---------- CORS RESPONSE ----------
function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  };
}

// ADD PAYMENT
async function addPayment(event) {
  try {
    const body = JSON.parse(event.body);

    const record = {
      paymentId: Date.now().toString(),
      tenantId: body.tenantId,
      tenantName: body.tenantName,
      room: body.room,
      month: body.month,
      year: body.year,
      amount: body.amount,
      deposit: body.deposit || 0,
      maintenance: body.maintenance || 0,
      method: body.method,
      status: body.status || "paid",
      date: body.date || new Date().toISOString().slice(0, 10)
    };

    await ddb.send(new PutCommand({ TableName: TABLE, Item: record }));

    return response(200, { message: "Payment saved", data: record });

  } catch (err) {
    return response(500, { error: err.toString() });
  }
}

// GET ALL PAYMENTS
async function getPayments() {
  try {
    const res = await ddb.send(new ScanCommand({ TableName: TABLE }));
    return response(200, res.Items || []);
  } catch (err) {
    return response(500, { error: err.toString() });
  }
}

// GET PAYMENTS BY TENANT
async function getTenantPayments(event) {
  try {
    const tenantId = event.pathParameters.tenantId;

    const result = await ddb.send(
      new ScanCommand({
        TableName: TABLE,
        FilterExpression: "tenantId = :tid",
        ExpressionAttributeValues: { ":tid": tenantId }
      })
    );

    return response(200, result.Items || []);
  } catch (err) {
    return response(500, { error: err.toString() });
  }
}

// UPDATE PAYMENT
async function updatePayment(event) {
  try {
    const paymentId = event.pathParameters.paymentId;
    const body = JSON.parse(event.body);

    const exp = [];
    const values = {};

    Object.keys(body).forEach((key) => {
      exp.push(`${key} = :${key}`);
      values[`:${key}`] = body[key];
    });

    await ddb.send(
      new UpdateCommand({
        TableName: TABLE,
        Key: { paymentId },
        UpdateExpression: `SET ${exp.join(", ")}`,
        ExpressionAttributeValues: values
      })
    );

    return response(200, { message: "Payment updated" });
  } catch (err) {
    return response(500, { error: err.toString() });
  }
}

// DELETE PAYMENT
async function deletePayment(event) {
  try {
    const paymentId = event.pathParameters.paymentId;

    await ddb.send(
      new DeleteCommand({
        TableName: TABLE,
        Key: { paymentId }
      })
    );

    return response(200, { message: "Payment deleted" });
  } catch (err) {
    return response(500, { error: err.toString() });
  }
}

module.exports = {
  addPayment,
  getPayments,
  getTenantPayments,
  updatePayment,
  deletePayment
};
